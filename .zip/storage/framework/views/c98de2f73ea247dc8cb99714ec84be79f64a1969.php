<section id="portfolio" class="portfolio section">
  <div class="container section-title" data-aos="fade-up">
    <h2>More From Our Blogs</h2>
    <p>Dive deeper into our collection of fishing insights, tips, and stories across Victoria. There's always more to explore from our blog archive.</p>
  </div>

  <div class="container">
    <div class="row">
      <?php
        $recent_blogs = $data['recent_blogs'];
      ?>
      <?php $__currentLoopData = $recent_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-12">
          <div class="blog-wrapper mb-5" onclick="">
            <div class="row">
              <div class="col-lg-3">
                <img
                  loading="lazy"
                  alt="<?php echo e($blog->blog_title); ?>"
                  src="<?php echo e(asset('img/blog-images/' . $blog->blog_img)); ?>"
                  data-src="<?php echo e(asset('img/blog-images/' . $blog->blog_img)); ?>"
                  class="img-responsive wp-post-image lzl lozad lazy-blur w-100"
                >
              </div>
              <div class="col-lg-9">
                <div class="time-wrapper">
                  <small>
                    <time datetime="<?php echo e(\Carbon\Carbon::parse($blog->blog_created_at)->format('Y-m-d')); ?>">
                      <?php echo e(\Carbon\Carbon::parse($blog->blog_created_at)->format('d M, Y')); ?>

                    </time>
                  </small>
                  <a href="<?php echo e(url('blog/' . $blog->id ?? '#')); ?>" class="blog-title">
                    <?php echo e($blog->blog_title); ?>

                  </a>
                  <p class="blog-text w-75"><?php echo e($blog->blog_sub_description); ?></p>
                </div>
                <a href="<?php echo e(url('blog/' . $blog->id ?? '#')); ?>" class="btn btn-info blog-readmore" style="background-color:#5d57f4; color:#fff;">Read More!</a>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section><?php /**PATH C:\xampp\htdocs\victoria\resources\views/segments/blogs-front-segment.blade.php ENDPATH**/ ?>