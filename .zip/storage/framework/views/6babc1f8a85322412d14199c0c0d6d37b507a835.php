
<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('components.front-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main class="main">

    <!-- Hero Section -->
    <?php echo $__env->make('segments.front-hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /Hero Section -->
    <?php echo $__env->make('segments.recent-blogs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('segments.blogs-front-segment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('segments.categories-segment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('segments.fishing-spots-segment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- about section -->

    <!-- /How We Work Section -->

    <!-- End Service Item -->

      <!-- /Services Section -->

    <!-- /Services Alt Section -->

    <!-- Call To Action 2 Section -->
    <!-- /Call To Action 2 Section -->

    <!-- Portfolio Section -->
    <!-- /Portfolio Section -->

    

    <!-- Faq Section -->
    <!-- /Faq Section -->

    <!-- team section location -->

    <!-- Testimonials Section -->
    <!-- /Testimonials Section -->

    <!-- Contact Section -->
    <!-- /Contact Section -->

  </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\victoria\resources\views/pages/index.blade.php ENDPATH**/ ?>