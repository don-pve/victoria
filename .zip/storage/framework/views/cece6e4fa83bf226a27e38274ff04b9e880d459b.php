<header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container position-relative">

      <a href="index.html" class="logo d-flex align-items-center me-auto me-xl-0">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.webp" alt=""> -->
        <!-- <h1 class="sitename">Invent</h1><span>.</span> -->
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="#hero">Home</a></li>
          <li><a href="#about">Blogs</a></li>
          
          <li><a href="#portfolio">Categories</a></li>
          
          
          
          <li><a href="#contact">Newsletter</a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

      

    </div>
  </header><?php /**PATH C:\xampp\htdocs\victoria\resources\views/components/front-header.blade.php ENDPATH**/ ?>