
<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('components.front-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main class="main">
    <?php
      $blog_data = $data['blog_data']; 
    ?>
    <!-- Page Title -->
    <div class="page-title">
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li class="current"><?php echo e(optional($blog_data)->blog_title ?? ''); ?></li>
          </ol>
        </div>
      </nav>
    </div><!-- End Page Title -->

    <!-- Portfolio Details Section -->
    <section id="portfolio-details" class="portfolio-details section">

      <div class="container" data-aos="fade-up">


        <div class="row justify-content-between gy-4 mt-4">

          <div class="col-lg-8" data-aos="fade-up">
            <div class="service-main-image aos-init aos-animate mb-5" data-aos="zoom-in" data-aos-delay="200">
              <img src="<?php echo e(asset('img/blog-images/' . $blog_data->blog_img)); ?>" alt="" class="img-fluid rounded-4">
            </div>
            <div class="portfolio-description">
              <h2><?php echo e(optional($blog_data)->blog_title ?? ''); ?></h2>
              <p>
                <?php echo e(optional($blog_data)->blog_content ?? ''); ?>

              </p>

            </div>
          </div>

          <div class="col-lg-3" data-aos="fade-up" data-aos-delay="100">
            <div class="portfolio-info">
              <h3>Project information</h3>
              <ul>
                <li><strong>Category</strong> Web design</li>
                <li><strong>Client</strong> ASU Company</li>
                <li><strong>Project date</strong> 01 March, 2020</li>
                <li><strong>Project URL</strong> <a href="#">www.example.com</a></li>
                <li><a href="#" class="btn-visit align-self-start">Visit Website</a></li>
              </ul>
            </div>
          </div>

        </div>

      </div>

    </section><!-- /Portfolio Details Section -->

  </main>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\victoria\resources\views/pages/blog-single.blade.php ENDPATH**/ ?>